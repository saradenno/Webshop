export const environment = {
  base_url: "http://localhost:8080/api",
};
