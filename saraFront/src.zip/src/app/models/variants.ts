export class Variants {
    id!:number;
    size!: number;
    color!: string;
    productId!:number;
    stock!:number;
    price!:number;
    imgURL!: string;
}
