export class User {
  public id!: number;
  public name!: string;
  public infix!: string;
  public lastName!: string;
  public email!: string;
  //public token: string;
}
