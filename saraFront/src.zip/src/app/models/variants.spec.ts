import { Variants } from './variants';

describe('Variants', () => {
  it('should create an instance', () => {
    expect(new Variants()).toBeTruthy();
  });
});
